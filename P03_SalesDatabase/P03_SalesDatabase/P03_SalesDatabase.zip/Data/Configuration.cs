﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data
{
    class Configuration
    {
        public static string ConecntionString { get; set; } = "Server=LAPTOP-0NSKHNUT\\SQLEXPRESS;Database=Sales;Integrated Security=True";
    }
}
