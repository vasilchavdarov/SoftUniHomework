﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    class Configuration
    {
        public static string ConentionString { get; set; } = "Server=LAPTOP-0NSKHNUT\\SQLEXPRESS;Database=Hospital;Integrated Security=True";
    }
}
