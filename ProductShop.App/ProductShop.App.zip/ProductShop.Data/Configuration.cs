﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.Data
{
    class Configuration
    {
        public static string ConecntionString => "Server=LAPTOP-0NSKHNUT\\SQLEXPRESS;Database=ProductsShop;Integrated Security=True";
    }
}
