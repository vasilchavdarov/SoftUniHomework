﻿namespace Instagraph.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => "Server=LAPTOP-0NSKHNUT\\SQLEXPRESS;Database=Instagraph;Integrated Security=True;";
    }
}
